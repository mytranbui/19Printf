FILLIT_CHECKER:

Ce test s'assure du bon fonctionnement de votre fillit.

pour lancer le test, faites la commande qui suit:

sh test.sh FILLIT_FOLDER

Avec FILLIT_FOLDER le dossier qui contient à sa racine votre fillit.

created by agadhgad 2015
