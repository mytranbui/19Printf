## logo credits

<img align="right"  src="./42FileChecker_cropped.png" width="45%" />Edouard Audeguy  
Illustrateur / Infographiste  
https://edouardaudeguy.wix.com/portfolio
